package com.coding.journal;

import java.util.ArrayList;

public class Mark {

    private String date;
    private String value;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Mark(String date, String value) {
        this.date = date;
        this.value = value;
    }

    public Mark() {
    }



    public static ArrayList<Mark> getTestingDatas() {
        ArrayList<Mark> list = new ArrayList<>();
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "4"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "4"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "4"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));
        list.add(new Mark("01.02", "5"));

        return list;
    }
}
